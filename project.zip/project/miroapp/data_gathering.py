






api_response_test = {'result': {'CHECKS': {'Account_check': {'Complete_Invoice': {'Gst_Portal': '-',
                                                              'Invoice_data': '',
                                                              'status': 'YES'},
                                         'Customer_Adress': {'Gst_Portal': 'No.71 '
                                                                           ', '
                                                                           'EPIP '
                                                                           'Industrial '
                                                                           'Area '
                                                                           ', '
                                                                           'Road '
                                                                           'No.3 '
                                                                           ', '
                                                                           'Bengaluru '
                                                                           'Urban '
                                                                           ', '
                                                                           'Karnataka '
                                                                           ', '
                                                                           '560066',
                                                             'Invoice_data': '#71, '
                                                                             'EPIP '
                                                                             'INDL '
                                                                             'AREA '
                                                                             ', '
                                                                             'HOODY '
                                                                             'VILLAGE, '
                                                                             'WHITEFIELD '
                                                                             'ROAD, '
                                                                             'KR '
                                                                             'PURAM\n'
                                                                             'HOBLI, '
                                                                             'BANGLORE, '
                                                                             'None, '
                                                                             'None, '
                                                                             '-560066',
                                                             'status': 'Not '
                                                                       'Matching'},
                                         'Customer_Name': {'Gst_Portal': 'GLODESI '
                                                                         'TECHNOLOGIES '
                                                                         'PRIVATE '
                                                                         'LIMITED',
                                                           'Invoice_data': 'GLODESI '
                                                                           'TECHNOLOGIES '
                                                                           'PRIVATE '
                                                                           'LIMITED',
                                                           'status': 'Matching'},
                                         'Invoice_Blocked_Credit': {'Gst_Portal': '',
                                                                    'Invoice_data': '',
                                                                    'status': 'Okay'},
                                         'Invoice_Date': {'Gst_Portal': ' ',
                                                          'Invoice_data': '2025-08-11',
                                                          'status': 'Okay'},
                                         'Invoice_Number': {'Gst_Portal': ' ',
                                                            'Invoice_data': '4765/25-26',
                                                            'status': 'Okay'},
                                         'Invoice_RCM-Services': {'Gst_Portal': '',
                                                                  'Invoice_data': '',
                                                                  'status': 'NO'},
                                         'Pre_year': {'Gst_Portal': '-',
                                                      'Invoice_data': '',
                                                      'status': 'NO'},
                                         'gstnumber_gstcharged': {'Gst_Portal': '',
                                                                  'Invoice_data': '',
                                                                  'status': 'Okay'},
                                         'valid_invoice': {'Gst_Portal': '-',
                                                           'Invoice_data': '',
                                                           'status': 'YES'}},
                       'data_from_gst': {'206AB_Compliance': {'fin_year': '2024-25',
                                                              'pan': 'AABFV9313N',
                                                              'pan_allotment_date': '1999-09-06',
                                                              'pan_name': 'VXXXXA '
                                                                          'MXXXL '
                                                                          'FXXXXXXXS',
                                                              'pan_operative_status': 'operative',
                                                              'specified_person': 'N'},
                                         'Filing Frequency': 'Invalid GSTIN. '
                                                             'Please navigate '
                                                             'to '
                                                             'https://www.gst.gov.in/help/helpmodules/ '
                                                             'to know more.',
                                         'Filing Status': 'Invalid GSTIN',
                                         'Pan_Status': {'aadhaar_linked': None,
                                                        'aadhaar_number': '',
                                                        'aadhaar_seeding_status': 'NA',
                                                        'address': {'building_name': 'No '
                                                                                     '365 '
                                                                                     '10th '
                                                                                     'cross',
                                                                    'city': 'BANGALORE',
                                                                    'country': 'India',
                                                                    'locality': 'Peenya '
                                                                                'I '
                                                                                'Stage '
                                                                                'S.O',
                                                                    'pincode': '560058',
                                                                    'state': 'Karnataka',
                                                                    'street_name': 'Peenya '
                                                                                   'Industrial '
                                                                                   'Area'},
                                                        'dob': '15/04/1991',
                                                        'email': '',
                                                        'first_name': '',
                                                        'fullname': 'VIJAYA '
                                                                    'METAL '
                                                                    'FINISHERS',
                                                        'gender': None,
                                                        'last_name': 'VIJAYA '
                                                                     'METAL '
                                                                     'FINISHERS',
                                                        'middle_name': '',
                                                        'mobile': '',
                                                        'pan': 'AABFV9313N',
                                                        'pan_status': 'Active',
                                                        'pan_type': 'Firm/Limited '
                                                                    'Liability '
                                                                    'Partnership'},
                                         'Vendor_Filing_status': 'Invalid '
                                                                 'GSTIN',
                                         'customer_gst_data': {'Address': 'No.71 '
                                                                          ', '
                                                                          'EPIP '
                                                                          'Industrial '
                                                                          'Area '
                                                                          ', '
                                                                          'Road '
                                                                          'No.3 '
                                                                          ', '
                                                                          'Bengaluru '
                                                                          'Urban '
                                                                          ', '
                                                                          'Karnataka '
                                                                          ', '
                                                                          '560066',
                                                               'Central tax Jurisdiction': 'RANGE-BED7',
                                                               'Central tax Jurisdiction Code': 'YT0702',
                                                               'Date of Registration': '01/07/2017',
                                                               'Duty': 'Regular',
                                                               'E-Invoice Status': 'Yes',
                                                               'Gstin': '29AAGCG0335D2ZX',
                                                               'Legal Name': 'GLODESI '
                                                                             'TECHNOLOGIES '
                                                                             'PRIVATE '
                                                                             'LIMITED',
                                                               'Nature of Business Activity': ['Factory '
                                                                                               '/ '
                                                                                               'Manufacturing'],
                                                               'State Jurisdiction Code': 'KA119',
                                                               'Trade Name': 'GLODESI '
                                                                             'TECHNOLOGIES '
                                                                             'PRIVATE '
                                                                             'LIMITED'},
                                         'vendor_gst_data': {'vendor_gst': 'Invalid '
                                                                           'Gst '
                                                                           'Number'}},
                       'e-invoice_data': {'einvoice_liability': 'InValid GST '
                                                                'Number',
                                          'reason': 'InValid GST Number',
                                          'status': 'Not Okay'},
                       'eway_bill_data': {'Invoice_No': {'e-waybill': 'GST '
                                                                      'Number '
                                                                      'is Not '
                                                                      'Valid',
                                                         'invoice': '4765/25-26'},
                                          'Total_Amount': {'e-waybill': 'GST '
                                                                        'Number '
                                                                        'is '
                                                                        'Not '
                                                                        'Valid',
                                                           'invoice': '4921.00'},
                                          'Vendor_Gst': {'e-waybill': 'GST '
                                                                      'Number '
                                                                      'is Not '
                                                                      'Valid',
                                                         'invoice': '29AABFV9313NIZL'},
                                          'reason': 'Vendor is liable to raise '
                                                    'E-Way Bill, but GST '
                                                    'Number is Not Valid',
                                          'status': 'not okay'},
                       'table_data': {'Table_Check_data': '[{"item_description":"DP '
                                                          'Angle","item_quantity":13.0,"unit_price":338.0,"product_code":"998873","tax_rate":6.0,"amount":4394.0,"qty_unitprice":4394.0,"qty_unit+rate_qty_unit":4657.64,"qty_unit+2_rate_qty_unit":4921.28,"check1":"correct"}]'},
                       'tax_check': {'Company_Gst_Valid': {'Gst_Portal': '',
                                                           'Invoice_data': '',
                                                           'status': 'YES'},
                                     'Company_Gst_mentioned': {'Gst_Portal': '',
                                                               'Invoice_data': '',
                                                               'status': 'YES'},
                                     'Vendor_206AB': {'Gst_Portal': 'N',
                                                      'Invoice_data': '',
                                                      'status': 'Okay'},
                                     'Vendor_Filing_status': {'Gst_Portal': 'Not '
                                                                            'fetched '
                                                                            'as '
                                                                            'no '
                                                                            'vendor '
                                                                            'Gst '
                                                                            'or '
                                                                            'Invalid '
                                                                            'Gst '
                                                                            'on '
                                                                            'Invoice',
                                                              'Invoice_data': ' ',
                                                              'status': 'Not '
                                                                        'fetched '
                                                                        'as no '
                                                                        'vendor '
                                                                        'Gst '
                                                                        'or '
                                                                        'Invalid '
                                                                        'Gst '
                                                                        'on '
                                                                        'Invoice'},
                                     'Vendor_Gst_Active': {'Gst_Portal': '',
                                                           'Invoice_data': '',
                                                           'status': 'NO'},
                                     'Vendor_Gst_Valid': {'Gst_Portal': 'Invalid '
                                                                        'Gst '
                                                                        'Number',
                                                          'Invoice_data': '29AABFV9313NIZL',
                                                          'status': 'NO'},
                                     'Vendor_Gst_mentioned': {'Gst_Portal': '',
                                                              'Invoice_data': '29AABFV9313NIZL',
                                                              'status': 'YES'},
                                     'Vendor_Pan-Adhar_Linked': {'Gst_Portal': None,
                                                                 'Invoice_data': '',
                                                                 'status': 'Not Okay'},
                                     'Vendor_Pan_Active': {'Gst_Portal': 'Not Active',
                                                           'Invoice_data': '',
                                                           'status': 'Not Okay'},
                                     'Vendor_TaxPayer_type': {'Gst_Portal': 'Invalid '
                                                                            'Gst '
                                                                            'Number',
                                                              'Invoice_data': '29AABFV9313NIZL',
                                                              'status': 'Invalid '
                                                                        'Gst '
                                                                        'Number'},
                                     'Vendor_Taxfiliging_Frequency': {'Gst_Portal': 'Not '
                                                                                    'fetched',
                                                                      'Invoice_data': ' ',
                                                                      'status': 'Not '
                                                                                'fetched'},
                                     'tax_type_on_invoice': {'Gst_Portal': ' ',
                                                             'Invoice_data': ' ',
                                                             'status': 'Okay'}}},
            'Invoice_data': {'Ack_No': None,
                             'Bank_Details': {'Account_holder_name': 'Dutch 5',
                                              'Bank_Account_No': None,
                                              'Email': None,
                                              'VendorAddress': '#365, 10th '
                                                               'Cross,IV '
                                                               'Phase, Peenya '
                                                               'Indl Area, '
                                                               'Bangalore, '
                                                               'Karnataka, '
                                                               '560058, INDIA'},
                             'Currency': 'INR',
                             'CustomerAddress': '#71, EPIP INDL AREA , HOODY '
                                                'VILLAGE, WHITEFIELD ROAD, KR '
                                                'PURAM\n'
                                                'HOBLI, BANGLORE, None, None, '
                                                '-560066',
                             'CustomerAddressRecipient': 'GLODESI TECHNOLOGIES '
                                                         'PRIVATE LIMITED',
                             'CustomerName': 'GLODESI TECHNOLOGIES PRIVATE '
                                             'LIMITED',
                             'Cutomer Gst No.': '29AAGCG0335D2ZX',
                             'EwayBill_No': None,
                             'Invoice items:': {'item#1': {'amount': '4394.0',
                                                           'item_description': 'DP '
                                                                               'Angle',
                                                           'item_quantity': 13.0,
                                                           'product_code': '998873',
                                                           'tax_rate': '6.00%\n'
                                                                       '6.00%',
                                                           'unit_price': '338.0'}},
                             'InvoiceDate': '2025-08-11',
                             'InvoiceId': '4765/25-26',
                             'InvoiceTotal': '4921.00',
                             'Irn_No': None,
                             'Payment_Term': 'Within 30 days',
                             'PurchaseOrder': '241000599',
                             'SubTotal': '4394.00',
                             'Tax Items': {'CGST': {'amount': '263.64'},
                                           'IGST': {'amount': '0.00'},
                                           'SGST': {'amount': '263.64'}},
                             'Tax_Invoice': 'Tax Invoice',
                             'TotalDiscount': '0.00',
                             'TotalTax': '527.28',
                             'Vendor Gst No.': '29AABFV9313NIZL',
                             'VendorAddress': '#365, 10th Cross,IV Phase, '
                                              'Peenya Indl Area, Bangalore, '
                                              'Karnataka, 560058, INDIA',
                             'VendorAddressRecipient': 'VIJAYA METAL FINISHERS',
                             'VendorName': 'Dutch 5',
                             'relevent_page': ['1']}}}
if __name__ == "__main__":
    #.get('data_from_gst',{}).get('eway_bill_data')
    ewy = api_response_test.get('result',{}).get('CHECKS').get('eway_bill_data')
    print(ewy)
   